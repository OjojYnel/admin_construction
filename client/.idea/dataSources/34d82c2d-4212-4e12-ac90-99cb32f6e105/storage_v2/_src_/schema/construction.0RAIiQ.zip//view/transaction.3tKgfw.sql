create view transaction as
select `construction`.`rentals`.`userId`                                                        AS `userid`,
       `construction`.`rentals`.`rentalid`                                                      AS `rental_id`,
       concat((`construction`.`rentals`.`duration` * `construction`.`equipments`.`equipPrice`)) AS `totalPayment`
from (`construction`.`equipments`
       join `construction`.`rentals` on ((`construction`.`equipments`.`equipId` = `construction`.`rentals`.`equipId`)));

